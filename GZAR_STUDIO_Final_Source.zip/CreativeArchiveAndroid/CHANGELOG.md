# Changelog

## 1.0.1 — Consolidated release candidate

- Consolidated archive, image-layer composition, audio preview/trim, AI integration and creative calculator into one source tree.
- Added project rename/delete/search and file search.
- Added AI image input to OpenAI and Gemini text analysis.
- Added playback-time Equalizer, BassBoost and room reverb controls.
- Added API 26–28 private Downloads fallback and API 29+ public Downloads export.
- Added layer slider/drag undo snapshots and bounded image decoding.
- Updated the GZAR launcher icon and app version.

- Added single-layer replacement, multi-select delete, alignment/nudge controls, and safer multi-select interaction.
- Added in-app video preview and keyframe-based MP4 remux trimming for supported codecs.

- Consolidated project archive, image-layer editor, Audio Lab, AI Studio and Creative Tools into one source project.
- Added keyframe-based MP4 trim/remux, layer export and layer alignment/transform controls.
- Added build workflow and static verification report.
