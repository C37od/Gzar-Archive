# GZAR STUDIO — Release candidate status

This archive consolidates the previously separate development changes into one Android source tree.

## Implemented in source

- Project create / rename / delete, project search, per-project file search, SAF import, persistent project metadata.
- In-app image, video and audio preview.
- Image-layer composition: add/replace, drag, scale, rotate, opacity, visibility, front-to-back ordering, lock (transforms disabled while locked), duplicate, single or multi-delete, align/nudge, undo/redo, transparent PNG export.
- Audio playback: seek, volume, playback speed, live Equalizer / BassBoost / PresetReverb when the Android device supports them; trim/remux supported audio streams. Effects are playback-only, not rendered to exported files.
- Audio trim/remux for supported AAC and AMR streams; unsupported codecs are rejected instead of silently producing a bad export.
- OpenAI and Gemini text chat and image analysis; last 20 requests are stored as local history; API keys are stored with AndroidX EncryptedSharedPreferences and masked in the UI.
- Creative Tools: FPS/frame-duration calculator, in-app video preview, and keyframe-based MP4 remux trim for supported video/audio tracks.
- Back navigation, scrollable mobile screens, search and scrolling improvements; simple FPS/frame duration calculator; GZAR simple launcher icon and app version 1.0.1.
- Updated simple GZAR launcher icon and app version 1.0.1.

## Known limitations / not implemented

- Layer Editor currently stores one shared local layer stack on the device; it is not yet attached to individual Archive project records.

- Full multitrack video editor, transitions, motion graphics timeline, video re-encoding/rendering/export. Current video cut is keyframe-based remux only.
- Offline audio DSP/export, waveform display, noise reduction and compressor.
- AI image generation, video analysis and audio transcription. API keys are encrypted at rest locally, but requests go directly from the app to the provider (there is no server-side proxy).
- General-purpose file copy/move/rename operations on arbitrary external document providers.

## Verification performed

- Kotlin compiler parser pass: no Kotlin syntax diagnostics found. The standalone compiler reports unresolved Android/AndroidX symbols because no platform/dependency classpath is installed; this is not a successful application compile.
- Multi-select delete index retention was corrected; destructive row actions are hidden during multi-select to avoid stale selection indexes.
- XML resources and AndroidManifest parsed successfully.
- PNG resource files decoded successfully.
- ZIP integrity checks passed after packaging.

## Verification not possible here

- No Android SDK, Android Gradle Plugin cache or Gradle executable is installed, and outbound DNS is unavailable. Therefore no APK build, emulator launch, device install, playback test, API-key test or export-on-device test was performed.
- Use the included GitHub Actions workflow or Android Studio to build the APK in an Android SDK-enabled environment. Do not treat source-level checks as a successful APK/device test.
