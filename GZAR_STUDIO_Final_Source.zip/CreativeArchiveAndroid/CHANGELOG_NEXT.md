# Development update

- Added audio segment start/end controls to Audio Lab.
- Added native Android audio-track trimming via MediaExtractor and MediaMuxer.
- Export writes the selected segment into the device Downloads collection.
- Existing archive preview, basic layer editor, AI text chat and FPS calculator retained.

Known limitations remain documented in DEVELOPMENT_STATUS.md.

## Layer composition export
- Added a real PNG export action to the Layer Editor.
- Visible layers are decoded from their persisted content URIs and composited in order onto a transparent 1600x1600 bitmap.
- Layer scale and drag offsets are applied to the exported composition.
- Export is written to the Android Downloads collection through MediaStore, with pending-state handling and cleanup on failure.
- This export path has been source-reviewed but not built or device-tested in this environment.

## Layer editor transform controls (2026-11-21)
- Added per-layer rotation control (-180 to 180 degrees).
- Added per-layer opacity control (0–100%).
- Persisted rotation and opacity in the editor's local JSON state, with defaults for older saved projects.
- Applied rotation and opacity in the live Compose preview.
- Applied the same rotation and opacity values when exporting the transparent PNG composite.
