package com.creativearchive

import android.content.Context
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.media.MediaExtractor
import android.media.MediaMuxer
import android.media.MediaFormat
import android.content.ContentValues
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import android.widget.VideoView
import android.graphics.Bitmap
import android.webkit.MimeTypeMap
import androidx.activity.ComponentActivity
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.graphics.graphicsLayer
import kotlin.math.roundToInt
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay

private val Ink = Color(0xFF101820)
private val Panel = Color(0xFF1E293B)
private val Blue = Color(0xFF2563EB)
private val Accent = Color(0xFF38BDF8)
private val Muted = Color(0xFF94A3B8)
private val White = Color(0xFFF1F5F9)

 data class Project(val id: Long, val name: String, val created: Long, val files: List<String> = emptyList())

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CreativeArchiveApp(this) }
    }
}

@Composable
fun CreativeArchiveApp(context: Context) {
    var selected by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf("Home") }
    var projects by remember { mutableStateOf(loadProjects(context)) }
    var showCreate by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var activeProjectId by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf<Long?>(null) }
    val activeProject = projects.firstOrNull { it.id == activeProjectId }
    var renameTarget by remember { mutableStateOf<Project?>(null) }
    var renameValue by remember { mutableStateOf("") }
    var deleteTarget by remember { mutableStateOf<Project?>(null) }
    var archiveQuery by remember { mutableStateOf("") }
    var projectFileQuery by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var previewFile by remember { mutableStateOf<Pair<Uri, String?>?>(null) }
    var lastBackPress by remember { mutableLongStateOf(0L) }

    BackHandler(enabled = true) {
        when {
            previewFile != null -> previewFile = null
            activeProject != null -> activeProjectId = null
            selected != "Home" -> selected = "Home"
            else -> {
                val now = System.currentTimeMillis()
                if (now - lastBackPress < 2000L) {
                    (context as? Activity)?.finish()
                } else {
                    lastBackPress = now
                    android.widget.Toast.makeText(context, "اضغط مرة أخرى للخروج من GZAR STUDIO", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val p = activeProject
        if (p != null && uris.isNotEmpty()) {
            uris.forEach { uri -> try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {} }
            val updated = p.copy(files = (p.files + uris.map { it.toString() }).distinct())
            projects = projects.map { if (it.id == p.id) updated else it }
            saveProjects(context, projects)
            activeProjectId = updated.id
            message = "تمت إضافة ${uris.size} ملف للمشروع"
        }
    }
    MaterialTheme(colorScheme = darkColorScheme(background = Ink, surface = Panel, primary = Blue, onBackground = White, onSurface = White)) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Home" to Icons.Default.Home, "Archive" to Icons.Default.Folder, "Editor" to Icons.Default.Layers, "AI Studio" to Icons.Default.AutoAwesome, "Audio" to Icons.Default.GraphicEq, "Tools" to Icons.Default.Tune).forEach { (name, icon) ->
                    NavigationBarItem(selected == name, { selected = name; activeProjectId = null }, { Icon(icon, name) }, label = { Text(name, fontSize = 9.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Accent, selectedTextColor = Accent, indicatorColor = Color(0xFF263B59), unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }) { padding ->
            val screenScroll = if (selected == "Archive" || selected == "Editor") Modifier else Modifier.verticalScroll(rememberScrollState())
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp).background(Ink).then(screenScroll)) {
                Spacer(Modifier.height(20.dp))
                when (selected) {
                    "Home" -> {
                        Text("GZAR STUDIO", color = White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                        Text("YOUR CREATIVE WORKSPACE", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                        Spacer(Modifier.height(22.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { StatCard("PROJECTS", projects.size.toString(), Modifier.weight(1f)); StatCard("FILES", projects.sumOf { it.files.size }.toString(), Modifier.weight(1f)); StatCard("WORKSPACE", "STUDIO", Modifier.weight(1f)) }
                        Spacer(Modifier.height(24.dp)); Text("WORKSPACE", color = Accent, fontWeight = FontWeight.Bold)
                        ModuleCard("Project Archive", "إنشاء مشاريعك وإضافة ملفاتك", Icons.Default.Folder) { selected = "Archive" }
                        ModuleCard("AI Design Studio", "محادثة الذكاء الاصطناعي وإعداد المزودين", Icons.Default.AutoAwesome) { selected = "AI Studio" }
                        ModuleCard("Audio Lab", "تشغيل ومعاينة الملفات الصوتية", Icons.Default.GraphicEq) { selected = "Audio" }
                        ModuleCard("Creative Tools", "أدوات حساب مدة الفيديو ومعدل الإطارات", Icons.Default.Tune) { selected = "Tools" }
                    }
                    "Archive" -> {
                        if (activeProject == null) {
                            Text("PROJECT ARCHIVE", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Text("مشاريعك محفوظة على هذا الهاتف", color = Muted)
                            Spacer(Modifier.height(16.dp))
                            Button(onClick = { newName = ""; showCreate = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("إنشاء مشروع جديد") }
                            Spacer(Modifier.height(12.dp))
                            OutlinedTextField(value = archiveQuery, onValueChange = { archiveQuery = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("البحث في المشاريع") }, leadingIcon = { Icon(Icons.Default.Search, null) })
                            if (projects.isEmpty()) EmptyState("لسه مفيش مشاريع", "اضغط إنشاء مشروع جديد للبدء")
                            else if (projects.none { it.name.contains(archiveQuery, ignoreCase = true) }) EmptyState("لا توجد نتائج", "جرّب اسمًا مختلفًا")
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(projects.filter { it.name.contains(archiveQuery, ignoreCase = true) }, key = { it.id }) { project ->
                                Card(Modifier.fillMaxWidth().clickable { activeProjectId = project.id; projectFileQuery = "" }, colors = CardDefaults.cardColors(containerColor = Panel)) {
                                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.FolderOpen, null, tint = Accent)
                                        Column(Modifier.weight(1f).padding(start = 10.dp)) { Text(project.name, color = White, fontWeight = FontWeight.SemiBold, maxLines = 1); Text("${project.files.size} ملف", color = Muted, fontSize = 11.sp) }
                                        IconButton(onClick = { renameTarget = project; renameValue = project.name }) { Icon(Icons.Default.Edit, "إعادة تسمية", tint = Muted) }
                                        IconButton(onClick = { deleteTarget = project }) { Icon(Icons.Default.DeleteOutline, "حذف المشروع", tint = Color(0xFFFF8A80)) }
                                        Icon(Icons.Default.ChevronRight, null, tint = Muted)
                                    }
                                }
                            } }
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = { activeProjectId = null }) { Icon(Icons.Default.ArrowBack, null, tint = White) }; Text(activeProject!!.name, color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                            Text("${activeProject!!.files.size} ملف داخل المشروع", color = Muted)
                            Spacer(Modifier.height(16.dp))
                            Button(onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Icon(Icons.Default.UploadFile, null); Spacer(Modifier.width(8.dp)); Text("إضافة ملفات من الهاتف") }
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(value = projectFileQuery, onValueChange = { projectFileQuery = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("البحث داخل ملفات المشروع") }, leadingIcon = { Icon(Icons.Default.Search, null) })
                            Spacer(Modifier.height(8.dp))
                            if (activeProject!!.files.isEmpty()) EmptyState("المشروع فارغ", "أضف صور أو فيديو أو صوت أو أي ملفات")
                            val projectFilesShown = activeProject!!.files.filter { getDisplayName(context, Uri.parse(it)).contains(projectFileQuery, ignoreCase = true) }
                            if (projectFilesShown.isEmpty() && activeProject!!.files.isNotEmpty()) EmptyState("لا توجد ملفات مطابقة", "جرّب اسمًا مختلفًا")
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(projectFilesShown) { fileUri ->
                                    val parsed = Uri.parse(fileUri)
                                    val displayName = remember(fileUri) { getDisplayName(context, parsed) }
                                    val mime = remember(fileUri) { getMimeType(context, parsed, displayName) }
                                    val isVideo = mime?.startsWith("video/") == true || displayName.substringAfterLast('.', "").lowercase() in listOf("mp4", "mkv", "mov", "avi", "webm", "3gp", "m4v")
                                    val isImage = mime?.startsWith("image/") == true
                                    val thumbnail by produceState<Bitmap?>(initialValue = null, fileUri) {
                                        value = withContext(Dispatchers.IO) { loadThumbnail(context, parsed, isVideo, isImage) }
                                    }
                                    DisposableEffect(thumbnail) { onDispose { try { thumbnail?.recycle() } catch (_: Exception) { } } }
                                    Card(
                                        Modifier.fillMaxWidth().clickable { previewFile = parsed to mime },
                                        colors = CardDefaults.cardColors(containerColor = Panel)
                                    ) {
                                        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                            if (thumbnail != null) {
                                                Image(bitmap = thumbnail!!.asImageBitmap(), contentDescription = "غلاف $displayName", modifier = Modifier.size(76.dp, 58.dp), contentScale = ContentScale.Crop)
                                            } else {
                                                Box(Modifier.size(76.dp, 58.dp).background(Color(0xFF263B59), RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                                                    Icon(if (isVideo) Icons.Default.PlayCircle else if (mime?.startsWith("audio/") == true) Icons.Default.GraphicEq else Icons.Default.InsertDriveFile, null, tint = Accent, modifier = Modifier.size(30.dp))
                                                }
                                            }
                                            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                                Text(displayName, color = White, fontWeight = FontWeight.Medium, maxLines = 2)
                                                Text(mime ?: "نوع ملف غير معروف", color = Muted, fontSize = 11.sp)
                                                if (isVideo) Text("اضغط للتشغيل", color = Accent, fontSize = 10.sp)
                                            }
                                            if (isVideo) Icon(Icons.Default.PlayArrow, null, tint = Accent)
                                            IconButton(onClick = {
                                                val updated = activeProject!!.copy(files = activeProject!!.files.filterNot { it == fileUri })
                                                projects = projects.map { if (it.id == updated.id) updated else it }
                                                saveProjects(context, projects)
                                                activeProjectId = updated.id
                                                message = "تم حذف الملف من المشروع فقط، ولم يتم حذفه من الهاتف"
                                            }) { Icon(Icons.Default.DeleteOutline, "إزالة من المشروع", tint = Muted) }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    "Editor" -> LayerEditor(context)
                    "Audio" -> AudioLab(context)
                    "AI Studio" -> AiStudio(context)
                    else -> CreativeTools(context)

                }
            }
        }
        previewFile?.let { (uri, mime) -> InternalMediaPreview(context, uri, mime, { previewFile = null }) }
        if (showCreate) AlertDialog(onDismissRequest = { showCreate = false }, containerColor = Panel, title = { Text("مشروع جديد", color = White) }, text = { OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("اسم المشروع") }, singleLine = true) }, confirmButton = { TextButton(onClick = { val name = newName.trim(); if (name.isNotEmpty()) { val p = Project(System.currentTimeMillis(), name, System.currentTimeMillis()); projects = projects + p; saveProjects(context, projects); showCreate = false; activeProjectId = p.id }; }) { Text("إنشاء") } }, dismissButton = { TextButton(onClick = { showCreate = false }) { Text("إلغاء") } })
        renameTarget?.let { target -> AlertDialog(onDismissRequest = { renameTarget = null }, containerColor = Panel, title = { Text("إعادة تسمية المشروع", color = White) }, text = { OutlinedTextField(value = renameValue, onValueChange = { renameValue = it }, singleLine = true, label = { Text("الاسم الجديد") }) }, confirmButton = { TextButton(onClick = { val value = renameValue.trim(); if (value.isNotEmpty()) { projects = projects.map { if (it.id == target.id) it.copy(name = value) else it }; saveProjects(context, projects) }; renameTarget = null }) { Text("حفظ") } }, dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("إلغاء") } }) }
        deleteTarget?.let { target -> AlertDialog(onDismissRequest = { deleteTarget = null }, containerColor = Panel, title = { Text("حذف المشروع؟", color = White) }, text = { Text("سيُحذف المشروع من GZAR STUDIO فقط. الملفات الأصلية على الهاتف لن تُحذف.", color = White) }, confirmButton = { TextButton(onClick = { projects = projects.filterNot { it.id == target.id }; saveProjects(context, projects); if (activeProjectId == target.id) activeProjectId = null; deleteTarget = null }) { Text("حذف", color = Color(0xFFFF8A80)) } }, dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("إلغاء") } }) }
        if (message.isNotBlank()) AlertDialog(onDismissRequest = { message = "" }, confirmButton = { TextButton(onClick = { message = "" }) { Text("تمام") } }, text = { Text(message) }, containerColor = Panel)
    }
}


@Composable
private fun LayerEditor(context: Context) {
    data class Layer(val uri: String, val x: Float = 0f, val y: Float = 0f, val scale: Float = 1f, val visible: Boolean = true, val rotation: Float = 0f, val alpha: Float = 1f, val locked: Boolean = false)
    fun readLayers(): List<Layer> = try {
        val a = JSONArray(context.getSharedPreferences("gzar_editor", 0).getString("layer_state", "[]") ?: "[]")
        (0 until a.length()).map { i -> a.getJSONObject(i).let { Layer(it.getString("uri"), it.optDouble("x",0.0).toFloat(), it.optDouble("y",0.0).toFloat(), it.optDouble("scale",1.0).toFloat(), it.optBoolean("visible",true), it.optDouble("rotation",0.0).toFloat(), it.optDouble("alpha",1.0).toFloat(), it.optBoolean("locked",false)) } }
    } catch (_: Exception) { loadLayerUris(context).map { Layer(it) } }
    fun persist(items: List<Layer>) {
        val a = JSONArray(); items.forEach { a.put(JSONObject().put("uri",it.uri).put("x",it.x).put("y",it.y).put("scale",it.scale).put("visible",it.visible).put("rotation",it.rotation).put("alpha",it.alpha).put("locked",it.locked)) }
        context.getSharedPreferences("gzar_editor",0).edit().putString("layer_state",a.toString()).putString("layers", JSONArray().also { arr -> items.forEach { arr.put(it.uri) } }.toString()).apply()
    }
    var layers by remember { mutableStateOf(readLayers()) }
    var selected by remember { mutableIntStateOf(-1) }
    var multiSelectMode by remember { mutableStateOf(false) }
    var multiSelected by remember { mutableStateOf(setOf<Int>()) }
    var undo by remember { mutableStateOf(listOf<List<Layer>>()) }
    var redo by remember { mutableStateOf(listOf<List<Layer>>()) }
    var sliderSnapshot by remember { mutableStateOf<List<Layer>?>(null) }
    var exportingComposite by remember { mutableStateOf(false) }
    var compositeMessage by remember { mutableStateOf("") }
    val editorScope = rememberCoroutineScope()
    fun commit(next: List<Layer>) { undo = (undo + listOf(layers)).takeLast(50); redo = emptyList(); layers = next; persist(next) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) { uris.forEach { try { context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {} }; commit(layers + uris.map { Layer(it.toString()) }); selected = layers.size }
    }
    val replacePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val index = selected
        if (uri != null && index in layers.indices) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            commit(layers.toMutableList().also { it[index] = it[index].copy(uri = uri.toString()) })
        }
    }
    Text("LAYER EDITOR", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Text("تركيب صور متعدد الطبقات · قفل ونسخ وتحريك وتنسيق", color = Muted)
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { picker.launch(arrayOf("image/*")) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.AddPhotoAlternate,null); Text(" إضافة") }
        OutlinedButton(enabled = selected in layers.indices, onClick = { replacePicker.launch(arrayOf("image/*")) }) { Text("استبدال") }
        OutlinedButton(enabled = undo.isNotEmpty(), onClick = { val prev=undo.last(); redo=(redo+listOf(layers)).takeLast(50); undo=undo.dropLast(1); layers=prev; persist(prev) }) { Text("تراجع") }
        OutlinedButton(enabled = redo.isNotEmpty(), onClick = { val next=redo.last(); undo=(undo+listOf(layers)).takeLast(50); redo=redo.dropLast(1); layers=next; persist(next) }) { Text("إعادة") }
    }
    Button(
        enabled = layers.any { it.visible } && !exportingComposite,
        onClick = {
            val snapshot = layers.toList()
            exportingComposite = true
            compositeMessage = ""
            editorScope.launch {
                try {
                    val result = withContext(Dispatchers.IO) { exportLayerComposite(context, snapshot.map { ExportLayer(it.uri, it.x, it.y, it.scale, it.rotation, it.alpha, it.visible) }) }
                    compositeMessage = "تم تصدير PNG: $result"
                } catch (e: Exception) { compositeMessage = "فشل التصدير: ${e.message ?: "خطأ غير معروف"}" }
                finally { exportingComposite = false }
            }
        }, modifier = Modifier.fillMaxWidth()
    ) { Text(if (exportingComposite) "جارٍ تصدير التركيب…" else "تصدير التركيب كصورة PNG") }
    if (compositeMessage.isNotBlank()) Text(compositeMessage, color = if (compositeMessage.startsWith("تم")) Accent else Color(0xFFFF8A80), fontSize = 11.sp)
    Card(Modifier.fillMaxWidth().height(270.dp), colors=CardDefaults.cardColors(containerColor=Color(0xFF0B1220))) {
        BoxWithConstraints(Modifier.fillMaxSize(), contentAlignment=Alignment.Center) {
            layers.indices.reversed().forEach { index ->
                val layer = layers[index]
                if (layer.visible) {
                    val bitmap by produceState<Bitmap?>(initialValue=null, layer.uri) { value=withContext(Dispatchers.IO) { decodeScaledBitmap(context, Uri.parse(layer.uri), 1200) } }
                    DisposableEffect(bitmap) { onDispose { try { bitmap?.recycle() } catch (_: Exception) { } } }
                    if (bitmap != null) Image(bitmap!!.asImageBitmap(), contentDescription="Layer $index", contentScale=ContentScale.Fit,
                        modifier=Modifier.fillMaxWidth(0.82f).height(220.dp).offset { IntOffset(layer.x.roundToInt(),layer.y.roundToInt()) }.graphicsLayer(scaleX=layer.scale,scaleY=layer.scale, rotationZ=layer.rotation, alpha=layer.alpha).pointerInput(index, selected) { detectDragGestures(onDragStart={ selected=index; if (!layer.locked) { undo = (undo + listOf(layers)).takeLast(50); redo = emptyList() } }) { change, drag ->
                            change.consume()
                            val old=layers[index]
                            if (!old.locked) {
                                layers=layers.toMutableList().also { it[index]=old.copy(x=old.x+drag.x,y=old.y+drag.y) }
                                persist(layers)
                            }
                        } }.clickable { selected=index })
                }
            }
            if (layers.isEmpty()) Text("أضف صورًا لبدء التركيب", color=Muted)
        }
    }
    Spacer(Modifier.height(10.dp))
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("الطبقات · ${layers.size}", color=Accent, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
        TextButton(onClick = { multiSelectMode = !multiSelectMode; multiSelected = emptySet() }) { Text(if (multiSelectMode) "إلغاء التحديد المتعدد" else "تحديد متعدد") }
    }
    if (multiSelectMode) Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
        Text("تم تحديد ${multiSelected.size}", color=Muted, modifier=Modifier.weight(1f))
        Button(enabled=multiSelected.isNotEmpty(), onClick={
            val removed = multiSelected
            val nextSelected = if (selected < 0 || selected in removed) -1 else selected - removed.count { it < selected }
            commit(layers.filterIndexed { i, _ -> i !in removed })
            selected = nextSelected
            multiSelected=emptySet(); multiSelectMode=false
        }) { Text("حذف المحدد") }
    }
    LazyColumn(Modifier.weight(1f, fill=false), verticalArrangement=Arrangement.spacedBy(6.dp)) {
        items(layers.size) { index -> val layer=layers[index]; val name=getDisplayName(context,Uri.parse(layer.uri))
            Card(Modifier.fillMaxWidth().clickable {
                if (multiSelectMode) multiSelected = if (index in multiSelected) multiSelected - index else multiSelected + index
                else selected=index
            }, colors=CardDefaults.cardColors(containerColor=if(selected==index || index in multiSelected) Color(0xFF263B59) else Panel)) {
                Row(Modifier.padding(7.dp), verticalAlignment=Alignment.CenterVertically) {
                    if (multiSelectMode) Checkbox(checked=index in multiSelected, onCheckedChange={ checked -> multiSelected = if (checked) multiSelected + index else multiSelected - index })
                    Text(name, color=White, modifier=Modifier.weight(1f), maxLines=1)
                    if (!multiSelectMode) {
                        IconButton(onClick={ commit(layers.toMutableList().also { it[index]=layer.copy(visible=!layer.visible) }) }) { Icon(if(layer.visible) Icons.Default.Visibility else Icons.Default.VisibilityOff,null,tint=Accent) }
                        IconButton(onClick={ if(index>0) { commit(layers.toMutableList().also { val v=it.removeAt(index); it.add(index-1,v) }); selected=index-1 } }) { Icon(Icons.Default.KeyboardArrowUp,null,tint=White) }
                        IconButton(onClick={ if(index<layers.lastIndex) { commit(layers.toMutableList().also { val v=it.removeAt(index); it.add(index+1,v) }); selected=index+1 } }) { Icon(Icons.Default.KeyboardArrowDown,null,tint=White) }
                        IconButton(onClick={ commit(layers.toMutableList().also { it[index]=layer.copy(locked=!layer.locked) }) }) { Icon(if(layer.locked) Icons.Default.Lock else Icons.Default.LockOpen,null,tint=if(layer.locked) Accent else Muted) }
                        IconButton(onClick={ commit(layers.toMutableList().also { it.add(index+1, layer.copy(x=layer.x+24f,y=layer.y+24f)) }); selected=index+1 }) { Icon(Icons.Default.ContentCopy,null,tint=White) }
                        IconButton(onClick={ commit(layers.filterIndexed { i,_->i!=index }); selected = when { selected == index -> -1; selected > index -> selected - 1; else -> selected } }) { Icon(Icons.Default.DeleteOutline,null,tint=Color(0xFFFF8A80)) }
                    }
                }
            }
        }
    }
    if(selected in layers.indices) {
        val layer=layers[selected]
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedButton(enabled=!layer.locked, onClick={ commit(layers.toMutableList().also { it[selected]=layer.copy(x=0f,y=0f) }) }, modifier=Modifier.weight(1f)) { Text("توسيط الطبقة") }
            OutlinedButton(enabled=!layer.locked, onClick={ commit(layers.toMutableList().also { it[selected]=layer.copy(x=0f,y=0f,scale=1f,rotation=0f,alpha=1f) }) }, modifier=Modifier.weight(1f)) { Text("إعادة ضبط") }
        }
        Text("محاذاة سريعة", color=Accent, fontWeight=FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            OutlinedButton(enabled=!layer.locked, onClick={ commit(layers.toMutableList().also { it[selected]=layer.copy(x=-260f) }) }, modifier=Modifier.weight(1f)) { Text("يسار") }
            OutlinedButton(enabled=!layer.locked, onClick={ commit(layers.toMutableList().also { it[selected]=layer.copy(x=260f) }) }, modifier=Modifier.weight(1f)) { Text("يمين") }
            OutlinedButton(enabled=!layer.locked, onClick={ commit(layers.toMutableList().also { it[selected]=layer.copy(y=-100f) }) }, modifier=Modifier.weight(1f)) { Text("أعلى") }
            OutlinedButton(enabled=!layer.locked, onClick={ commit(layers.toMutableList().also { it[selected]=layer.copy(y=100f) }) }, modifier=Modifier.weight(1f)) { Text("أسفل") }
        }
        Text("تحريك دقيق", color=Accent, fontWeight=FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            OutlinedButton(enabled=!layer.locked, onClick={ commit(layers.toMutableList().also { it[selected]=layer.copy(x=layer.x-5f) }) }, modifier=Modifier.weight(1f)) { Text("←") }
            OutlinedButton(enabled=!layer.locked, onClick={ commit(layers.toMutableList().also { it[selected]=layer.copy(x=layer.x+5f) }) }, modifier=Modifier.weight(1f)) { Text("→") }
            OutlinedButton(enabled=!layer.locked, onClick={ commit(layers.toMutableList().also { it[selected]=layer.copy(y=layer.y-5f) }) }, modifier=Modifier.weight(1f)) { Text("↑") }
            OutlinedButton(enabled=!layer.locked, onClick={ commit(layers.toMutableList().also { it[selected]=layer.copy(y=layer.y+5f) }) }, modifier=Modifier.weight(1f)) { Text("↓") }
        }
        Text("حجم الطبقة · ${(layer.scale * 100).toInt()}%", color=Muted)
        Slider(value=layer.scale.coerceIn(0.3f,2.5f), onValueChange={ v -> if (sliderSnapshot == null) sliderSnapshot = layers; layers=layers.toMutableList().also { it[selected]=it[selected].copy(scale=v) }; persist(layers) }, onValueChangeFinished={ sliderSnapshot?.let { undo = (undo + listOf(it)).takeLast(50); redo = emptyList() }; sliderSnapshot = null }, valueRange=0.3f..2.5f, enabled=!layer.locked)
        Text("الدوران · ${layer.rotation.toInt()}°", color=Muted)
        Slider(value=layer.rotation.coerceIn(-180f,180f), onValueChange={ v -> if (sliderSnapshot == null) sliderSnapshot = layers; layers=layers.toMutableList().also { it[selected]=it[selected].copy(rotation=v) }; persist(layers) }, onValueChangeFinished={ sliderSnapshot?.let { undo = (undo + listOf(it)).takeLast(50); redo = emptyList() }; sliderSnapshot = null }, valueRange=-180f..180f, enabled=!layer.locked)
        Text("الشفافية · ${(layer.alpha * 100).toInt()}%", color=Muted)
        Slider(value=layer.alpha.coerceIn(0f,1f), onValueChange={ v -> if (sliderSnapshot == null) sliderSnapshot = layers; layers=layers.toMutableList().also { it[selected]=it[selected].copy(alpha=v) }; persist(layers) }, onValueChangeFinished={ sliderSnapshot?.let { undo = (undo + listOf(it)).takeLast(50); redo = emptyList() }; sliderSnapshot = null }, valueRange=0f..1f, enabled=!layer.locked)
        Text(if(layer.locked) "الطبقة مقفولة · افتح القفل للسماح بتحريكها" else "اسحب العنصر داخل مساحة العمل لتحريكه", color=Muted, fontSize=11.sp)
    }
}

private data class ExportLayer(val uri: String, val x: Float, val y: Float, val scale: Float, val rotation: Float, val alpha: Float, val visible: Boolean)

private fun exportLayerComposite(context: Context, layers: List<ExportLayer>): String {
    val width = 1600
    val height = 1600
    val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    try {
        val canvas = android.graphics.Canvas(output)
        canvas.drawColor(android.graphics.Color.TRANSPARENT, android.graphics.PorterDuff.Mode.CLEAR)
        val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG)
        layers.asReversed().forEach { layer ->
            if (!layer.visible) return@forEach
            val bitmap = decodeScaledBitmap(context, Uri.parse(layer.uri), 1200)
                ?: throw IllegalStateException("تعذر قراءة إحدى الطبقات")
            try {
                val maxSide = 1200f
                val fit = minOf(maxSide / bitmap.width, maxSide / bitmap.height, 1f) * layer.scale
                val w = bitmap.width * fit
                val h = bitmap.height * fit
                val left = (width - w) / 2f + layer.x * 2f
                val top = (height - h) / 2f + layer.y * 2f
                paint.alpha = (layer.alpha.coerceIn(0f, 1f) * 255).toInt()
                canvas.save()
                canvas.rotate(layer.rotation, left + w / 2f, top + h / 2f)
                canvas.drawBitmap(bitmap, null, android.graphics.RectF(left, top, left + w, top + h), paint)
                canvas.restore()
                paint.alpha = 255
            } finally { bitmap.recycle() }
        }
        val name = "GZAR_composite_${System.currentTimeMillis()}.png"
        return saveOutputToDownloads(context, name, "image/png") { stream ->
            if (!output.compress(Bitmap.CompressFormat.PNG, 100, stream)) throw IllegalStateException("تعذر ضغط الصورة")
        }
    } finally { output.recycle() }
}


private fun decodeScaledBitmap(context: Context, uri: Uri, maxSide: Int): Bitmap? {
    return try {
        val resolver = context.contentResolver
        val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth / sample, bounds.outHeight / sample) > maxSide * 2) sample *= 2
        val options = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
        resolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, options) }
    } catch (_: Exception) { null }
}

private fun readBoundedBytes(context: Context, uri: Uri, limit: Int): ByteArray {
    val input = context.contentResolver.openInputStream(uri) ?: throw IllegalStateException("تعذر قراءة الملف")
    input.use { stream ->
        val output = java.io.ByteArrayOutputStream()
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val count = stream.read(buffer)
            if (count < 0) break
            total += count
            if (total > limit) throw IllegalArgumentException("حجم الملف يتجاوز الحد المسموح")
            output.write(buffer, 0, count)
        }
        return output.toByteArray()
    }
}


private fun saveOutputToDownloads(context: Context, displayName: String, mimeType: String, writer: (java.io.OutputStream) -> Unit): String {
    if (Build.VERSION.SDK_INT >= 29) {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
            put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
            put("is_pending", 1)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(Uri.parse("content://media/external/downloads"), values)
            ?: throw IllegalStateException("تعذر إنشاء الملف في Downloads")
        try {
            resolver.openOutputStream(uri)?.use(writer) ?: throw IllegalStateException("تعذر فتح الملف للكتابة")
            resolver.update(uri, ContentValues().apply { put("is_pending", 0) }, null, null)
            return "Downloads/$displayName"
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
    }
    val folder = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir, "GZAR_STUDIO")
    if (!folder.exists() && !folder.mkdirs()) throw IllegalStateException("تعذر إنشاء مجلد التصدير")
    val outputFile = File(folder, displayName)
    java.io.FileOutputStream(outputFile).use(writer)
    return outputFile.absolutePath
}

private fun loadLayerUris(c: Context): List<String> = try { val a=JSONArray(c.getSharedPreferences("gzar_editor",0).getString("layers","[]") ?: "[]"); (0 until a.length()).map { a.getString(it) } } catch (_: Exception) { emptyList() }
private fun saveLayerUris(c: Context, xs: List<String>) { val a=JSONArray(); xs.forEach { a.put(it) }; c.getSharedPreferences("gzar_editor",0).edit().putString("layers",a.toString()).apply() }

@Composable
private fun AudioLab(context: Context) {
    var audioUri by remember { mutableStateOf<Uri?>(null) }
    var playing by remember { mutableStateOf(false) }
    var ready by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var durationMs by remember { mutableIntStateOf(0) }
    var positionMs by remember { mutableIntStateOf(0) }
    var volume by remember { mutableFloatStateOf(1f) }
    var speed by remember { mutableFloatStateOf(1f) }
    var trimStartMs by remember { mutableIntStateOf(0) }
    var trimEndMs by remember { mutableIntStateOf(0) }
    var exporting by remember { mutableStateOf(false) }
    var exportMessage by remember { mutableStateOf("") }
    var bassLevel by remember { mutableFloatStateOf(0f) }
    var toneBass by remember { mutableFloatStateOf(0f) }
    var toneTreble by remember { mutableFloatStateOf(0f) }
    var reverbEnabled by remember { mutableStateOf(false) }
    var effectsMessage by remember { mutableStateOf("") }
    val equalizer = remember { mutableStateOf<android.media.audiofx.Equalizer?>(null) }
    val bassBoost = remember { mutableStateOf<android.media.audiofx.BassBoost?>(null) }
    val presetReverb = remember { mutableStateOf<android.media.audiofx.PresetReverb?>(null) }
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        audioUri = uri
        ready = false; playing = false; error = ""; durationMs = 0; positionMs = 0; trimStartMs = 0; trimEndMs = 0; exportMessage = ""
        if (uri != null) try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
    }
    val player = remember(audioUri) { mutableStateOf<MediaPlayer?>(null) }
    DisposableEffect(audioUri) {
        val uri = audioUri
        if (uri != null) try {
            val mp = MediaPlayer(); player.value = mp
            mp.setDataSource(context, uri)
            mp.setOnPreparedListener { p ->
                durationMs = p.duration.coerceAtLeast(0); trimEndMs = durationMs; p.setVolume(volume, volume); ready = true
                try {
                    equalizer.value = android.media.audiofx.Equalizer(0, p.audioSessionId).apply { enabled = true }
                    bassBoost.value = android.media.audiofx.BassBoost(0, p.audioSessionId).apply { enabled = true; setStrength(0) }
                    presetReverb.value = android.media.audiofx.PresetReverb(0, p.audioSessionId).apply { preset = android.media.audiofx.PresetReverb.PRESET_MEDIUMROOM; enabled = reverbEnabled }
                    effectsMessage = "المؤثرات الصوتية متاحة لهذا الجهاز"
                } catch (e: Exception) {
                    effectsMessage = "بعض مؤثرات الصوت غير مدعومة على هذا الجهاز"
                }
            }
            mp.setOnCompletionListener { playing = false; positionMs = durationMs }
            mp.setOnErrorListener { _, _, _ -> error = "تعذر تشغيل الملف الصوتي"; playing = false; true }
            mp.prepareAsync()
        } catch (_: Exception) { error = "تعذر فتح الملف الصوتي" }
        onDispose {
            try { equalizer.value?.release() } catch (_: Exception) { }; equalizer.value = null
            try { bassBoost.value?.release() } catch (_: Exception) { }; bassBoost.value = null
            try { presetReverb.value?.release() } catch (_: Exception) { }; presetReverb.value = null
            try { player.value?.release() } catch (_: Exception) { }; player.value = null
        }
    }
    LaunchedEffect(playing, ready, audioUri) {
        while (playing && ready) {
            val p = player.value
            if (p != null) try { positionMs = p.currentPosition.coerceIn(0, durationMs.coerceAtLeast(0)) } catch (_: Exception) { }
            delay(250)
        }
    }
    fun timeLabel(ms: Int): String {
        val total = (ms / 1000).coerceAtLeast(0)
        return "%02d:%02d".format(total / 60, total % 60)
    }
    fun applyTone(bass: Float, treble: Float) {
        val eq = equalizer.value ?: return
        try {
            val range = eq.bandLevelRange
            for (index in 0 until eq.numberOfBands.toInt()) {
                val centerHz = eq.getCenterFreq(index.toShort()) / 1000
                val requested = when { centerHz < 250 -> bass; centerHz > 2000 -> treble; else -> 0f }
                val raw = (range[1].toFloat() * requested / 100f).toInt()
                eq.setBandLevel(index.toShort(), raw.coerceIn(range[0].toInt(), range[1].toInt()).toShort())
            }
        } catch (_: Exception) { effectsMessage = "تعذر تطبيق إعدادات Equalizer" }
    }
    Text("AUDIO LAB", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Text("مشغل صوت داخلي مع تحكم في الموضع ومستوى الصوت والسرعة", color = Muted)
    Spacer(Modifier.height(16.dp))
    Button(onClick = { picker.launch(arrayOf("audio/*")) }, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Default.AudioFile, null); Spacer(Modifier.width(8.dp)); Text("اختيار ملف صوتي")
    }
    if (audioUri == null) EmptyState("لا يوجد ملف محدد", "اختر ملفًا صوتيًا للبدء") else {
        Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.GraphicEq, null, tint = Accent, modifier = Modifier.size(58.dp))
                Text(getDisplayName(context, audioUri!!), color = White, fontWeight = FontWeight.Bold, maxLines = 2)
                Text(if (ready) "جاهز للتشغيل" else "جارٍ تجهيز الصوت…", color = Muted)
                Spacer(Modifier.height(8.dp))
                Slider(
                    value = if (durationMs > 0) positionMs.toFloat().coerceIn(0f, durationMs.toFloat()) else 0f,
                    onValueChange = { positionMs = it.toInt() },
                    onValueChangeFinished = { if (ready) try { player.value?.seekTo(positionMs) } catch (_: Exception) { } },
                    valueRange = 0f..durationMs.coerceAtLeast(1).toFloat(), enabled = ready && durationMs > 0
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(timeLabel(positionMs), color = Muted, fontSize = 11.sp)
                    Text(timeLabel(durationMs), color = Muted, fontSize = 11.sp)
                }
                Button(enabled = ready, onClick = {
                    val p = player.value ?: return@Button
                    if (p.isPlaying) { p.pause(); playing = false }
                    else { p.start(); playing = true }
                }) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null); Text(if (playing) "إيقاف مؤقت" else "تشغيل") }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VolumeDown, null, tint = Accent)
                    Slider(value = volume, onValueChange = { volume = it; try { player.value?.setVolume(it, it) } catch (_: Exception) { } }, valueRange = 0f..1f, modifier = Modifier.weight(1f))
                    Text("${(volume * 100).toInt()}%", color = Muted, fontSize = 11.sp)
                }
                Text("سرعة التشغيل", color = White, modifier = Modifier.align(Alignment.Start))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(0.75f, 1f, 1.25f, 1.5f, 2f).forEach { rate ->
                        FilterChip(selected = speed == rate, onClick = {
                            speed = rate
                            try { player.value?.playbackParams = player.value?.playbackParams?.setSpeed(rate) ?: android.media.PlaybackParams().setSpeed(rate) } catch (_: Exception) { }
                        }, label = { Text("${rate}x") })
                    }
                }
                if (error.isNotBlank()) Text(error, color = Color(0xFFFF8A80))
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Text("مؤثرات مباشرة أثناء التشغيل", color = White, fontWeight = FontWeight.Bold)
                Text("Bass Boost · Equalizer · Reverb", color = Muted, fontSize = 11.sp)
                Text("تعزيز الجهير · ${(bassLevel).toInt()}%", color = Muted, fontSize = 12.sp)
                Slider(value = bassLevel, onValueChange = { bassLevel = it; try { bassBoost.value?.setStrength((it * 10).toInt().toShort()); bassBoost.value?.enabled = it > 0f } catch (_: Exception) { effectsMessage = "تعذر تطبيق Bass Boost" } }, valueRange = 0f..100f, enabled = ready)
                Text("خفض/رفع الترددات المنخفضة · ${toneBass.toInt()}%", color = Muted, fontSize = 12.sp)
                Slider(value = toneBass, onValueChange = { toneBass = it; applyTone(toneBass, toneTreble) }, valueRange = -100f..100f, enabled = ready)
                Text("خفض/رفع الترددات العالية · ${toneTreble.toInt()}%", color = Muted, fontSize = 12.sp)
                Slider(value = toneTreble, onValueChange = { toneTreble = it; applyTone(toneBass, toneTreble) }, valueRange = -100f..100f, enabled = ready)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Reverb · صدى الغرفة", color = White, modifier = Modifier.weight(1f))
                    Switch(checked = reverbEnabled, onCheckedChange = { reverbEnabled = it; try { presetReverb.value?.enabled = it } catch (_: Exception) { effectsMessage = "تعذر تطبيق Reverb" } }, enabled = ready)
                }
                if (effectsMessage.isNotBlank()) Text(effectsMessage, color = Muted, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp)) {
                Text("قص الصوت وتصديره", color = White, fontWeight = FontWeight.Bold)
                Text("بداية المقطع: ${timeLabel(trimStartMs)}", color = Muted, fontSize = 12.sp)
                Slider(value = trimStartMs.toFloat().coerceIn(0f, durationMs.coerceAtLeast(1).toFloat()), onValueChange = { trimStartMs = it.toInt().coerceAtMost((trimEndMs - 500).coerceAtLeast(0)) }, valueRange = 0f..durationMs.coerceAtLeast(1).toFloat(), enabled = ready && durationMs > 500)
                Text("نهاية المقطع: ${timeLabel(trimEndMs)}", color = Muted, fontSize = 12.sp)
                Slider(value = trimEndMs.toFloat().coerceIn(0f, durationMs.coerceAtLeast(1).toFloat()), onValueChange = { trimEndMs = it.toInt().coerceAtLeast((trimStartMs + 500).coerceAtMost(durationMs)) }, valueRange = 0f..durationMs.coerceAtLeast(1).toFloat(), enabled = ready && durationMs > 500)
                Button(enabled = ready && !exporting && trimEndMs > trimStartMs, onClick = {
                    val source = audioUri ?: return@Button
                    exporting = true; exportMessage = ""
                    scope.launch {
                        try {
                            val output = withContext(Dispatchers.IO) { trimAudioToDownloads(context, source, trimStartMs, trimEndMs) }
                            exportMessage = "تم تصدير المقطع: $output"
                        } catch (e: Exception) { exportMessage = "فشل التصدير: ${e.message ?: "خطأ غير معروف"}" }
                        finally { exporting = false }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text(if (exporting) "جارٍ القص والتصدير…" else "قص وتصدير إلى التنزيلات") }
                if (exportMessage.isNotBlank()) Text(exportMessage, color = if (exportMessage.startsWith("تم")) Accent else Color(0xFFFF8A80), fontSize = 12.sp)
            }
        }
    }
    Spacer(Modifier.height(12.dp))
    Text("القص يصدّر المسار الأصلي دون إعادة ترميز. مؤثرات Bass Boost وEqualizer وReverb تعمل أثناء التشغيل فقط، ولا تُطبّق على الملف المصدّر.", color = Muted, fontSize = 12.sp)
}

private fun trimAudioToDownloads(context: Context, source: Uri, startMs: Int, endMs: Int): String {
    require(endMs > startMs) { "نطاق القص غير صالح" }
    val extractor = MediaExtractor()
    var muxer: MediaMuxer? = null
    val temp = File(context.cacheDir, "gzar_trim_${System.currentTimeMillis()}.mp4")
    try {
        extractor.setDataSource(context, source, null)
        val audioTrack = (0 until extractor.trackCount).firstOrNull { extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true }
            ?: throw IllegalArgumentException("الملف لا يحتوي على مسار صوت")
        extractor.selectTrack(audioTrack)
        val format = extractor.getTrackFormat(audioTrack)
        val audioMime = format.getString(MediaFormat.KEY_MIME).orEmpty()
        val supportedAudio = setOf("audio/mp4a-latm", "audio/3gpp", "audio/amr-wb")
        if (audioMime !in supportedAudio) throw IllegalArgumentException("صيغة الصوت $audioMime لا يدعمها القص المباشر حاليًا. جرّب ملف AAC/M4A أو AMR.")
        muxer = MediaMuxer(temp.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val outputTrack = muxer.addTrack(format)
        muxer.start()
        extractor.seekTo(startMs * 1000L, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
        val buffer = java.nio.ByteBuffer.allocate(4 * 1024 * 1024)
        val info = android.media.MediaCodec.BufferInfo()
        val endUs = endMs * 1000L
        var writtenSamples = 0
        while (true) {
            buffer.clear()
            val size = extractor.readSampleData(buffer, 0)
            if (size < 0) break
            val time = extractor.sampleTime
            if (time < 0 || time >= endUs) break
            if (time >= startMs * 1000L) {
                info.offset = 0; info.size = size; info.presentationTimeUs = time - startMs * 1000L
                info.flags = extractor.sampleFlags
                muxer.writeSampleData(outputTrack, buffer, info)
                writtenSamples++
            }
            if (!extractor.advance()) break
        }
        if (writtenSamples == 0) throw IllegalStateException("لم يتم العثور على عينات صوت في المقطع المحدد")
        muxer.stop()
        muxer.release(); muxer = null
        val extension = if (audioMime == "audio/mp4a-latm") "m4a" else "mp4"
        val outputName = "GZAR_trim_${System.currentTimeMillis()}.$extension"
        val savedLocation = saveOutputToDownloads(context, outputName, "audio/mp4") { output -> temp.inputStream().use { it.copyTo(output) } }
        return "تم الحفظ: $savedLocation"
    } finally {
        try { muxer?.stop() } catch (_: Exception) { }
        try { muxer?.release() } catch (_: Exception) { }
        extractor.release()
        temp.delete()
    }
}

@Composable
private fun AiStudio(context: Context) {
    var provider by remember { mutableStateOf("OpenAI") }
    var openKey by remember { mutableStateOf(readSecureKey(context, "openai_key")) }
    var geminiKey by remember { mutableStateOf(readSecureKey(context, "gemini_key")) }
    var showKeys by remember { mutableStateOf(false) }
    var prompt by remember { mutableStateOf("") }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var answer by remember { mutableStateOf("") }
    var aiHistory by remember { mutableStateOf(loadAiHistory(context)) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        imageUri = uri
        if (uri != null) try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
    }
    Text("AI STUDIO", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Text("محادثة فعلية عبر OpenAI أو Gemini", color = Muted)
    Spacer(Modifier.height(12.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(selected = provider == "OpenAI", onClick = { provider="OpenAI" }, label = { Text("OpenAI") })
        FilterChip(selected = provider == "Gemini", onClick = { provider="Gemini" }, label = { Text("Gemini") })
    }
    OutlinedButton(onClick = { showKeys = !showKeys }, modifier = Modifier.fillMaxWidth()) { Text(if (showKeys) "إخفاء إعداد المفاتيح" else "إعداد مفاتيح API") }
    if (showKeys) {
        OutlinedTextField(value = openKey, onValueChange = { openKey=it }, label = { Text("OpenAI API Key") }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
        OutlinedTextField(value = geminiKey, onValueChange = { geminiKey=it }, label = { Text("Gemini API Key") }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
        Button(onClick = { writeSecureKeys(context, openKey, geminiKey) }, modifier = Modifier.fillMaxWidth()) { Text("حفظ المفاتيح بشكل مشفر") }
    }
    Spacer(Modifier.height(12.dp))
    OutlinedTextField(value = prompt, onValueChange = { prompt=it }, label = { Text("اكتب طلبك للذكاء الاصطناعي") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton(onClick = { imagePicker.launch(arrayOf("image/*")) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.AddPhotoAlternate, null); Spacer(Modifier.width(6.dp)); Text("إرفاق صورة") }
        if (imageUri != null) TextButton(onClick = { imageUri = null }) { Text("إزالة الصورة") }
    }
    imageUri?.let { Text("مرفق: ${getDisplayName(context, it)}", color = Accent, fontSize = 12.sp, maxLines = 1) }
    Button(enabled = !busy && (prompt.isNotBlank() || imageUri != null), onClick = {
        val key = if (provider == "OpenAI") openKey.trim() else geminiKey.trim()
        if (key.isBlank()) { error = "أضف مفتاح $provider أولًا من إعدادات المفاتيح" }
        else {
            busy = true; error = ""; answer = ""
            scope.launch {
                try {
                    val selectedImage = imageUri
                    val bytes = selectedImage?.let { withContext(Dispatchers.IO) { readBoundedBytes(context, it, 12 * 1024 * 1024) } }
                    val mime = selectedImage?.let { context.contentResolver.getType(it) } ?: "image/jpeg"
                    val sentPrompt = prompt.trim().ifBlank { "حلل هذه الصورة واشرح محتواها بالتفصيل." }
                    val conversationContext = aiHistory.filter { it.provider == provider }.take(6).asReversed()
                        .joinToString("\n\n") { "المستخدم: ${it.prompt}\nالمساعد: ${it.answer}" }
                    val requestPrompt = if (conversationContext.isBlank()) sentPrompt else "$conversationContext\n\nالمستخدم: $sentPrompt"
                    answer = requestAi(provider, key, requestPrompt, bytes, mime)
                    aiHistory = (listOf(AiHistoryItem(provider, sentPrompt, answer, System.currentTimeMillis())) + aiHistory).take(20)
                    saveAiHistory(context, aiHistory)
                }
                catch (e: Exception) { error = e.message ?: "فشل الاتصال بمزود الذكاء الاصطناعي" }
                finally { busy = false }
            }
        }
    }, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "جارٍ الاتصال…" else "إرسال") }
    if (error.isNotBlank()) Text(error, color = Color(0xFFFF8A80), fontSize = 12.sp)
    if (answer.isNotBlank()) Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) { Text(answer, color = White, modifier = Modifier.padding(14.dp)) }
    if (aiHistory.isNotEmpty()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("سجل الطلبات الأخيرة", color = Accent, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = { aiHistory = emptyList(); saveAiHistory(context, aiHistory) }) { Text("مسح السجل") }
        }
        aiHistory.forEach { item ->
            Card(Modifier.fillMaxWidth().clickable { provider = item.provider; prompt = item.prompt; answer = item.answer }, colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(12.dp)) {
                    Text("${item.provider} · ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(item.createdAt))}", color = Accent, fontSize = 10.sp)
                    Text(item.prompt, color = White, maxLines = 2)
                    Text(item.answer, color = Muted, maxLines = 3)
                }
            }
        }
    }
    Text("يدعم المحادثة النصية وتحليل الصور عبر OpenAI وGemini. تحليل الفيديو وتوليد الوسائط غير مفعّل في هذا الإصدار.", color = Muted, fontSize = 12.sp)
}

private data class AiHistoryItem(val provider: String, val prompt: String, val answer: String, val createdAt: Long)

private fun loadAiHistory(context: Context): List<AiHistoryItem> = try {
    val raw = context.getSharedPreferences("gzar_ai_history", Context.MODE_PRIVATE).getString("items", "[]") ?: "[]"
    val array = JSONArray(raw)
    (0 until array.length()).map { i -> array.getJSONObject(i).let { AiHistoryItem(it.getString("provider"), it.getString("prompt"), it.getString("answer"), it.optLong("createdAt")) } }
} catch (_: Exception) { emptyList() }

private fun saveAiHistory(context: Context, items: List<AiHistoryItem>) {
    val array = JSONArray()
    items.take(20).forEach { item -> array.put(JSONObject().put("provider", item.provider).put("prompt", item.prompt).put("answer", item.answer).put("createdAt", item.createdAt)) }
    context.getSharedPreferences("gzar_ai_history", Context.MODE_PRIVATE).edit().putString("items", array.toString()).apply()
}

private suspend fun requestAi(provider: String, key: String, prompt: String, imageBytes: ByteArray? = null, imageMime: String = "image/jpeg"): String = withContext(Dispatchers.IO) {
    val encodedImage = imageBytes?.let { android.util.Base64.encodeToString(it, android.util.Base64.NO_WRAP) }
    val (url, body) = if (provider == "OpenAI") {
        val content = if (encodedImage == null) JSONObject().put("role", "user").put("content", prompt) else {
            val parts = JSONArray()
                .put(JSONObject().put("type", "text").put("text", prompt))
                .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:$imageMime;base64,$encodedImage")))
            JSONObject().put("role", "user").put("content", parts)
        }
        "https://api.openai.com/v1/chat/completions" to JSONObject()
            .put("model", "gpt-4o-mini")
            .put("messages", JSONArray().put(content))
    } else {
        val input = JSONArray().put(JSONObject().put("type", "text").put("text", prompt))
        if (encodedImage != null) input.put(JSONObject().put("type", "image").put("data", encodedImage).put("mime_type", imageMime))
        "https://generativelanguage.googleapis.com/v1beta/interactions" to JSONObject()
            .put("model", "gemini-3.8-flash")
            .put("store", false)
            .put("input", input)
    }
    val connection = java.net.URL(url).openConnection() as java.net.HttpURLConnection
    try {
        connection.requestMethod = "POST"; connection.connectTimeout = 20000; connection.readTimeout = 60000
        connection.setRequestProperty("Content-Type", "application/json")
        if (provider == "OpenAI") connection.setRequestProperty("Authorization", "Bearer $key") else connection.setRequestProperty("x-goog-api-key", key)
        connection.doOutput = true
        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val raw = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code !in 200..299) throw IllegalStateException("خطأ من $provider ($code): ${raw.take(500)}")
        val json = JSONObject(raw)
        if (provider == "OpenAI") json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        else {
            val steps = json.optJSONArray("steps") ?: JSONArray()
            val answerParts = mutableListOf<String>()
            for (i in 0 until steps.length()) {
                val step = steps.getJSONObject(i)
                if (step.optString("type") == "model_output") {
                    val content = step.optJSONArray("content") ?: JSONArray()
                    for (j in 0 until content.length()) {
                        val part = content.getJSONObject(j)
                        if (part.optString("type") == "text") answerParts += part.optString("text")
                    }
                }
            }
            answerParts.filter { it.isNotBlank() }.joinToString("\n\n").ifBlank { throw IllegalStateException("لم يرجع Gemini نصًا في الاستجابة") }
        }
    } finally { connection.disconnect() }
}

private fun securePrefs(context: Context) = EncryptedSharedPreferences.create(
    context, "gzar_secure_ai",
    MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
)
private fun readSecureKey(context: Context, key: String): String = try { securePrefs(context).getString(key, "") ?: "" } catch (_: Exception) { "" }
private fun writeSecureKeys(context: Context, openAi: String, gemini: String) { try { securePrefs(context).edit().putString("openai_key", openAi).putString("gemini_key", gemini).apply() } catch (_: Exception) { android.widget.Toast.makeText(context, "تعذر حفظ المفاتيح المشفرة", android.widget.Toast.LENGTH_LONG).show() } }

@Composable
private fun CreativeTools(context: Context) {
    Text("CREATIVE TOOLS", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
    Text("أدوات مساعدة للمونتاج", color = Muted)
    Spacer(Modifier.height(16.dp))
    var fps by remember { mutableStateOf("30") }; var frames by remember { mutableStateOf("1800") }
    Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
        Text("حاسبة مدة الفيديو", color = White, fontWeight = FontWeight.Bold)
        OutlinedTextField(value=fps, onValueChange={fps=it.filter(Char::isDigit)}, label={Text("FPS")}, modifier=Modifier.fillMaxWidth())
        OutlinedTextField(value=frames, onValueChange={frames=it.filter(Char::isDigit)}, label={Text("عدد الفريمات")}, modifier=Modifier.fillMaxWidth())
        val duration = (frames.toDoubleOrNull() ?: 0.0) / (fps.toDoubleOrNull()?.takeIf { it > 0 } ?: 1.0)
        Text("المدة: ${"%.2f".format(duration)} ثانية", color=Accent, fontWeight=FontWeight.Bold)
    } }
    Spacer(Modifier.height(18.dp))
    VideoTrimTool(context)
}

@Composable
private fun VideoTrimTool(context: Context) {
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var durationMs by remember { mutableIntStateOf(0) }
    var startMs by remember { mutableIntStateOf(0) }
    var endMs by remember { mutableIntStateOf(0) }
    var rotation by remember { mutableIntStateOf(0) }
    var exporting by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        videoUri = uri; durationMs = 0; startMs = 0; endMs = 0; status = ""
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        }
    }
    LaunchedEffect(videoUri) {
        val uri = videoUri
        if (uri != null) {
            val metadata = withContext(Dispatchers.IO) {
                val retriever = MediaMetadataRetriever()
                try {
                    retriever.setDataSource(context, uri)
                    Pair(retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toIntOrNull() ?: 0,
                        retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0)
                } finally { retriever.release() }
            }
            durationMs = metadata.first.coerceAtLeast(0)
            endMs = durationMs
            rotation = metadata.second
        }
    }
    fun label(ms: Int): String {
        val sec = (ms / 1000).coerceAtLeast(0)
        return "%02d:%02d".format(sec / 60, sec % 60)
    }
    Text("قص الفيديو", color = White, fontWeight = FontWeight.Bold)
    Text("قص مباشر دون إعادة ترميز؛ نقطة البداية قد تتحرك إلى أقرب إطار رئيسي Keyframe.", color = Muted, fontSize = 11.sp)
    Button(onClick = { picker.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Default.VideoLibrary, null); Spacer(Modifier.width(8.dp)); Text("اختيار فيديو")
    }
    val uri = videoUri
    if (uri != null) {
        Text(getDisplayName(context, uri), color = White, fontWeight = FontWeight.SemiBold, maxLines = 1)
        AndroidView(factory = { ctx ->
            VideoView(ctx).apply {
                setVideoURI(uri)
                val controller = android.widget.MediaController(ctx)
                controller.setAnchorView(this)
                setMediaController(controller)
                setOnPreparedListener { player -> player.isLooping = true; start() }
            }
        }, modifier = Modifier.fillMaxWidth().height(210.dp), onRelease = { it.stopPlayback() })
        Text("المدة الكاملة: ${label(durationMs)}", color = Muted, fontSize = 12.sp)
        Text("البداية: ${label(startMs)}", color = Muted, fontSize = 12.sp)
        Slider(value = startMs.toFloat().coerceIn(0f, durationMs.coerceAtLeast(1).toFloat()), onValueChange = { startMs = it.toInt().coerceAtMost((endMs - 500).coerceAtLeast(0)) }, valueRange = 0f..durationMs.coerceAtLeast(1).toFloat(), enabled = durationMs > 500)
        Text("النهاية: ${label(endMs)}", color = Muted, fontSize = 12.sp)
        Slider(value = endMs.toFloat().coerceIn(0f, durationMs.coerceAtLeast(1).toFloat()), onValueChange = { endMs = it.toInt().coerceAtLeast((startMs + 500).coerceAtMost(durationMs)) }, valueRange = 0f..durationMs.coerceAtLeast(1).toFloat(), enabled = durationMs > 500)
        Button(enabled = durationMs > 0 && endMs > startMs && !exporting, onClick = {
            exporting = true; status = ""
            scope.launch {
                try {
                    val saved = withContext(Dispatchers.IO) { trimVideoToDownloads(context, uri, startMs, endMs, rotation) }
                    status = "تم تصدير الفيديو: $saved"
                } catch (e: Exception) { status = "فشل قص الفيديو: ${e.message ?: "صيغة غير مدعومة"}" }
                finally { exporting = false }
            }
        }, modifier = Modifier.fillMaxWidth()) { Text(if (exporting) "جارٍ القص…" else "قص وتصدير MP4") }
        if (status.isNotBlank()) Text(status, color = if (status.startsWith("تم")) Accent else Color(0xFFFF8A80), fontSize = 11.sp)
    } else EmptyState("لا يوجد فيديو محدد", "اختر مقطعًا لمعاينته وقصه")
}

private fun trimVideoToDownloads(context: Context, source: Uri, startMs: Int, endMs: Int, rotation: Int): String {
    require(startMs >= 0 && endMs > startMs) { "نطاق القص غير صالح" }
    val extractor = MediaExtractor()
    var muxer: MediaMuxer? = null
    val temp = File(context.cacheDir, "gzar_video_trim_${System.currentTimeMillis()}.mp4")
    try {
        extractor.setDataSource(context, source, null)
        val tracks = mutableListOf<Pair<Int, Int>>()
        var hasVideo = false
        muxer = MediaMuxer(temp.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        for (track in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(track)
            val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
            val supported = when {
                mime.startsWith("video/") -> mime in setOf("video/avc", "video/hevc", "video/mp4v-es")
                mime.startsWith("audio/") -> mime in setOf("audio/mp4a-latm", "audio/3gpp", "audio/amr-wb")
                else -> false
            }
            if (mime.startsWith("video/") && !supported) throw IllegalArgumentException("ترميز الفيديو $mime غير مدعوم للقص المباشر")
            if (mime.startsWith("audio/") && !supported) throw IllegalArgumentException("ترميز الصوت $mime غير مدعوم للقص المباشر")
            if (supported) {
                val outputTrack = muxer.addTrack(format)
                tracks.add(track to outputTrack)
                extractor.selectTrack(track)
                if (mime.startsWith("video/")) hasVideo = true
            }
        }
        if (!hasVideo) throw IllegalArgumentException("لم يتم العثور على مسار فيديو مدعوم")
        if (rotation in listOf(0, 90, 180, 270)) muxer.setOrientationHint(rotation)
        muxer.start()
        val requestedStartUs = startMs * 1000L
        val endUs = endMs * 1000L
        extractor.seekTo(requestedStartUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
        val baseTimeUs = extractor.sampleTime.takeIf { it >= 0 } ?: requestedStartUs
        val trackMap = tracks.toMap()
        val buffer = java.nio.ByteBuffer.allocate(8 * 1024 * 1024)
        val info = android.media.MediaCodec.BufferInfo()
        var written = 0
        while (true) {
            val sourceTrack = extractor.sampleTrackIndex
            if (sourceTrack < 0) break
            val timeUs = extractor.sampleTime
            if (timeUs < 0 || timeUs >= endUs) break
            val outputTrack = trackMap[sourceTrack]
            if (outputTrack != null && timeUs >= baseTimeUs) {
                buffer.clear()
                val size = extractor.readSampleData(buffer, 0)
                if (size < 0) break
                info.offset = 0
                info.size = size
                info.presentationTimeUs = (timeUs - baseTimeUs).coerceAtLeast(0L)
                info.flags = extractor.sampleFlags
                muxer.writeSampleData(outputTrack, buffer, info)
                written++
            }
            if (!extractor.advance()) break
        }
        if (written == 0) throw IllegalStateException("لم يتم العثور على إطارات/عينات ضمن المقطع")
        muxer.stop(); muxer.release(); muxer = null
        val outputName = "GZAR_video_${System.currentTimeMillis()}.mp4"
        return saveOutputToDownloads(context, outputName, "video/mp4") { output -> temp.inputStream().use { it.copyTo(output) } }
    } finally {
        try { muxer?.stop() } catch (_: Exception) { }
        try { muxer?.release() } catch (_: Exception) { }
        extractor.release()
        temp.delete()
    }
}

fun loadProjects(context: Context): List<Project> = try {
    val raw = context.getSharedPreferences("gzar_archive", Context.MODE_PRIVATE).getString("projects", "[]") ?: "[]"
    val arr = JSONArray(raw); (0 until arr.length()).map { i -> val o = arr.getJSONObject(i); val f = o.optJSONArray("files") ?: JSONArray(); Project(o.getLong("id"), o.getString("name"), o.getLong("created"), (0 until f.length()).map { f.getString(it) }) }
} catch (_: Exception) { emptyList() }
fun saveProjects(context: Context, projects: List<Project>) {
    val arr = JSONArray(); projects.forEach { p -> val files = JSONArray(); p.files.forEach { files.put(it) }; arr.put(JSONObject().put("id", p.id).put("name", p.name).put("created", p.created).put("files", files)) }
    context.getSharedPreferences("gzar_archive", Context.MODE_PRIVATE).edit().putString("projects", arr.toString()).apply()
}

@Composable fun StatCard(label: String, value: String, modifier: Modifier = Modifier) { Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) { Column(Modifier.padding(11.dp)) { Text(value, color = Accent, fontSize = 19.sp, fontWeight = FontWeight.Bold); Text(label, color = Muted, fontSize = 9.sp) } } }
@Composable fun ModuleCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) { Card(Modifier.fillMaxWidth().padding(bottom = 9.dp).clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(42.dp).background(Color(0xFF1D3B60), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Accent) }; Column(Modifier.weight(1f).padding(start = 12.dp)) { Text(title, color = White, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Muted, fontSize = 11.sp) }; Icon(Icons.Default.ChevronRight, null, tint = Muted) } } }
@Composable fun EmptyState(title: String, body: String) { Column(Modifier.fillMaxWidth().padding(vertical = 30.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Inventory2, null, tint = Muted, modifier = Modifier.size(42.dp)); Spacer(Modifier.height(10.dp)); Text(title, color = White, fontWeight = FontWeight.Bold); Text(body, color = Muted, fontSize = 12.sp) } }


private fun getDisplayName(context: Context, uri: Uri): String {
    var name: String? = null
    try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) name = cursor.getString(0)
        }
    } catch (_: Exception) { }
    return name?.takeIf { it.isNotBlank() } ?: (uri.lastPathSegment?.substringAfterLast('/') ?: "ملف بدون اسم")
}

private fun getMimeType(context: Context, uri: Uri, name: String): String? {
    val fromProvider = try { context.contentResolver.getType(uri) } catch (_: Exception) { null }
    if (!fromProvider.isNullOrBlank() && fromProvider != "application/octet-stream") return fromProvider
    val extension = name.substringAfterLast('.', "").lowercase()
    return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension) ?: when (extension) {
        "mkv" -> "video/x-matroska"
        "avi" -> "video/x-msvideo"
        "mov" -> "video/quicktime"
        "mp4", "m4v" -> "video/mp4"
        "3gp" -> "video/3gpp"
        else -> fromProvider
    }
}

private fun loadThumbnail(context: Context, uri: Uri, isVideo: Boolean, isImage: Boolean): Bitmap? {
    return try {
        if (isVideo) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, uri)
                retriever.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    ?: retriever.getFrameAtTime(0)
            } finally { retriever.release() }
        } else if (isImage) {
            if (Build.VERSION.SDK_INT >= 29) context.contentResolver.loadThumbnail(uri, android.util.Size(240, 180), null)
            else decodeScaledBitmap(context, uri, 240)
        } else null
    } catch (_: Exception) { null }
}



@Composable
private fun InternalMediaPreview(context: Context, uri: Uri, mime: String?, onDismiss: () -> Unit) {
    val name = remember(uri) { getDisplayName(context, uri) }
    val type = mime ?: getMimeType(context, uri, name).orEmpty()
    val isImage = type.startsWith("image/")
    val isVideo = type.startsWith("video/")
    val isAudio = type.startsWith("audio/")
    val image by produceState<Bitmap?>(initialValue = null, uri, isImage) {
        value = if (isImage) withContext(Dispatchers.IO) {
            try { decodeScaledBitmap(context, uri, 1800) }
            catch (_: Exception) { null }
        } else null
    }
    DisposableEffect(image) { onDispose { try { image?.recycle() } catch (_: Exception) { } } }
    var audioReady by remember(uri) { mutableStateOf(false) }
    var audioPlaying by remember(uri) { mutableStateOf(false) }
    var audioError by remember(uri) { mutableStateOf<String?>(null) }
    val playerState = remember(uri, isAudio) { mutableStateOf<MediaPlayer?>(null) }
    DisposableEffect(uri, isAudio) {
        if (isAudio) {
            val player = MediaPlayer()
            playerState.value = player
            try {
                player.setDataSource(context, uri)
                player.setOnPreparedListener { audioReady = true }
                player.setOnCompletionListener { audioPlaying = false }
                player.setOnErrorListener { _, _, _ -> audioError = "تعذر تشغيل الملف الصوتي"; audioPlaying = false; true }
                player.prepareAsync()
            } catch (_: Exception) { audioError = "تعذر فتح الملف الصوتي" }
        }
        onDispose {
            try { playerState.value?.release() } catch (_: Exception) { }
            playerState.value = null
        }
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(modifier = Modifier.fillMaxWidth().padding(16.dp), shape = RoundedCornerShape(20.dp), color = Panel) {
            Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(name, color = White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 2)
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "إغلاق", tint = White) }
                }
                Spacer(Modifier.height(12.dp))
                when {
                    isImage -> if (image != null) Image(bitmap = image!!.asImageBitmap(), contentDescription = name, modifier = Modifier.fillMaxWidth().heightIn(max = 520.dp), contentScale = ContentScale.Fit) else Text("تعذر عرض الصورة", color = Muted)
                    isVideo -> AndroidView(
                        factory = { ctx -> VideoView(ctx).apply { setVideoURI(uri); setOnPreparedListener { it.isLooping = false; start() } } },
                        modifier = Modifier.fillMaxWidth().height(230.dp)
                    )
                    isAudio -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.GraphicEq, null, tint = Accent, modifier = Modifier.size(72.dp))
                        Text(if (audioReady) "الصوت جاهز للتشغيل" else "جارٍ تجهيز الصوت…", color = Muted)
                        Spacer(Modifier.height(12.dp))
                        Button(enabled = audioReady, onClick = {
                            val player = playerState.value ?: return@Button
                            if (player.isPlaying) { player.pause(); audioPlaying = false }
                            else { player.start(); audioPlaying = true }
                        }) { Icon(if (audioPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text(if (audioPlaying) "إيقاف مؤقت" else "تشغيل") }
                        audioError?.let { Text(it, color = Color(0xFFFF8A80)) }
                    }
                    else -> Text("لا تتوفر معاينة داخلية لهذا النوع من الملفات: $type", color = Muted)
                }
            }
        }
    }
}
