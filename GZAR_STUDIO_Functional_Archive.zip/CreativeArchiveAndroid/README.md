# Creative Archive — Android starter

واجهة تأسيسية لتطبيق Android باسم Creative Archive باستخدام Kotlin وJetpack Compose.

## فتح المشروع
1. فك ضغط الملف.
2. افتح مجلد `CreativeArchiveAndroid` من Android Studio.
3. انتظر Gradle Sync.
4. شغّل التطبيق على هاتف Android أو محاكي.

## الموجود حالياً
- واجهة عربية/إنجليزية أولية.
- لوحة رئيسية.
- تبويبات الأرشيف وAI Studio وAudio Lab والأدوات.
- تصميم داكن مع لمسات برتقالية.

## غير المنفذ بعد
هذه نسخة UI starter وليست تطبيقاً مكتملاً. لم يتم بعد ربط:
- اختيار الملفات والتخزين المحلي وقاعدة بيانات المشاريع.
- مشغل ومعاينة الفيديو والصوت.
- استخراج الكلام وتوقيت الكلمات (word-level alignment).
- تحليل الفيديو وقراءة FPS والمدة تلقائياً.
- نماذج إصلاح الصور ورفع الدقة.
- معالجة الألوان والصوت والتصدير.

## بنية التطوير المقترحة
- Android: Kotlin + Jetpack Compose
- Local data: Room
- File access: Android Storage Access Framework
- Media preview/metadata: AndroidX Media3 + MediaMetadataRetriever
- Audio transcription/alignment: خدمة Speech-to-Text تدعم timestamps
- AI image enhancement: نموذج معالجة صور عبر API أو نموذج محلي مناسب
- Background processing: WorkManager

لا تضع مفاتيح API داخل التطبيق مباشرة؛ استخدم backend آمن لإدارة المفاتيح والطلبات.
