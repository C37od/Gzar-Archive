package com.creativearchive

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101820)
private val Panel = Color(0xFF1E293B)
private val Orange = Color(0xFF2563EB)
private val Accent = Color(0xFF38BDF8)
private val Muted = Color(0xFF94A3B8)
private val White = Color(0xFFF1F5F9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CreativeArchiveApp() }
    }
}

@Composable
fun CreativeArchiveApp() {
    var selected by remember { mutableStateOf("Home") }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Ink, surface = Panel, primary = Orange,
        onBackground = White, onSurface = White, onPrimary = Ink
    )) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    val items = listOf(
                        "Home" to Icons.Default.Home,
                        "Archive" to Icons.Default.Folder,
                        "AI Studio" to Icons.Default.AutoAwesome,
                        "Audio" to Icons.Default.GraphicEq,
                        "Tools" to Icons.Default.Tune
                    )
                    items.forEach { (name, icon) ->
                        NavigationBarItem(
                            selected = selected == name,
                            onClick = { selected = name },
                            icon = { Icon(icon, contentDescription = name) },
                            label = { Text(name, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Orange,
                                selectedTextColor = Orange,
                                indicatorColor = Color(0xFF263B59),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            when (selected) {
                "Home" -> HomeScreen(padding) { selected = it }
                "Archive" -> ArchiveScreen(padding)
                "AI Studio" -> ModuleScreen(padding, "AI Studio", "فحص التصميم، إزالة الخلفية، إصلاح العناصر، ورفع الجودة", listOf("Design Check", "Image Fix", "AI Upscaler", "Background Remover"))
                "Audio" -> ModuleScreen(padding, "Audio Lab", "تحليل الكلام والموسيقى واستخراج توقيتات الكلمات", listOf("Import Audio", "Speech Transcription", "Word Timestamps", "Waveform & Silence Detection"))
                else -> ModuleScreen(padding, "Creative Tools", "أدوات المشروع وإعداداته", listOf("Video Analyzer", "Color Lab", "Sound Lab", "Export & Reports"))
            }
        }
    }
}

@Composable
fun Page(padding: PaddingValues, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp).background(Ink), content = content)
}

@Composable
fun HomeScreen(padding: PaddingValues, navigate: (String) -> Unit) {
    Page(padding) {
        Spacer(Modifier.height(22.dp))
        Text("CREATIVE ARCHIVE", color = White, fontSize = 23.sp, fontWeight = FontWeight.Black)
        Text("YOUR PERSONAL AI CREATIVE STUDIO", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(22.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("PROJECTS", "00", Modifier.weight(1f))
            StatCard("ASSETS", "00", Modifier.weight(1f))
            StatCard("AI TOOLS", "08", Modifier.weight(1f))
        }
        Spacer(Modifier.height(24.dp))
        Text("WORKSPACE", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        ModuleCard("Project Archive", "ملفاتك ومشاريعك في مكان واحد", Icons.Default.Folder) { navigate("Archive") }
        ModuleCard("AI Design Studio", "فحص الصور وتحسينها وإصلاح الأخطاء", Icons.Default.AutoAwesome) { navigate("AI Studio") }
        ModuleCard("Audio Intelligence", "كلمات الصوت وتوقيتها والفريمات", Icons.Default.GraphicEq) { navigate("Audio") }
        ModuleCard("Video · Color · Sound", "تحليل الفيديو وإدارة الألوان والصوت", Icons.Default.Movie) { navigate("Tools") }
        Spacer(Modifier.height(12.dp))
        Text("ملاحظة: هذه نسخة تأسيسية للواجهة. وظائف المعالجة والذكاء الاصطناعي ستُربط في مراحل التطوير التالية.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(value, color = Orange, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(label, color = Muted, fontSize = 9.sp)
        }
    }
}

@Composable
fun ModuleCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(bottom = 9.dp).clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Color(0xFF1D3B60), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = Accent)
            }
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(title, color = White, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Muted, fontSize = 11.sp)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = Muted)
        }
    }
}

@Composable
fun ArchiveScreen(padding: PaddingValues) {
    Page(padding) {
        Spacer(Modifier.height(22.dp))
        Text("PROJECT ARCHIVE", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("إدارة وتنظيم ملفات العمل", color = Muted)
        Spacer(Modifier.height(20.dp))
        Button(onClick = { }, colors = ButtonDefaults.buttonColors(containerColor = Orange), modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("إنشاء مشروع جديد")
        }
        Spacer(Modifier.height(18.dp))
        listOf("Videos", "Images & PNG", "Audio & Music", "GFX & Overlays", "Project Files", "Exports").forEach {
            ModuleCard(it, "مجلد جاهز لتنظيم ملفات المشروع", Icons.Default.Folder) {}
        }
        Text("الخطوة القادمة: ربط منتقي ملفات Android وحفظ بيانات المشاريع محلياً.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun ModuleScreen(padding: PaddingValues, title: String, description: String, tools: List<String>) {
    Page(padding) {
        Spacer(Modifier.height(22.dp))
        Text(title.uppercase(), color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(description, color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(20.dp))
        tools.forEach { tool ->
            ModuleCard(tool, "وحدة ضمن خطة التطوير", Icons.Default.Build) {}
        }
        Spacer(Modifier.height(12.dp))
        Text("هذه الوحدات ظاهرة في النموذج، وسيتم توصيل كل أداة بمحركها الفعلي قبل اعتبارها جاهزة للاستخدام.", color = Muted, fontSize = 11.sp)
    }
}
