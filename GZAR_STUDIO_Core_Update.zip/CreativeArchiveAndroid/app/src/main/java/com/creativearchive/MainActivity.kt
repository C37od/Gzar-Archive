package com.creativearchive

import android.content.Context
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.media.MediaMetadataRetriever
import android.graphics.Bitmap
import android.webkit.MimeTypeMap
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val Ink = Color(0xFF101820)
private val Panel = Color(0xFF1E293B)
private val Blue = Color(0xFF2563EB)
private val Accent = Color(0xFF38BDF8)
private val Muted = Color(0xFF94A3B8)
private val White = Color(0xFFF1F5F9)

 data class Project(val id: Long, val name: String, val created: Long, val files: List<String> = emptyList())

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CreativeArchiveApp(this) }
    }
}

@Composable
fun CreativeArchiveApp(context: Context) {
    var selected by remember { mutableStateOf("Home") }
    var projects by remember { mutableStateOf(loadProjects(context)) }
    var showCreate by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var activeProject by remember { mutableStateOf<Project?>(null) }
    var message by remember { mutableStateOf("") }
    var lastBackPress by remember { mutableLongStateOf(0L) }

    BackHandler(enabled = true) {
        when {
            activeProject != null -> activeProject = null
            selected != "Home" -> selected = "Home"
            else -> {
                val now = System.currentTimeMillis()
                if (now - lastBackPress < 2000L) {
                    (context as? Activity)?.finish()
                } else {
                    lastBackPress = now
                    android.widget.Toast.makeText(context, "اضغط مرة أخرى للخروج من GZAR STUDIO", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val p = activeProject
        if (p != null && uris.isNotEmpty()) {
            uris.forEach { uri -> try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {} }
            val updated = p.copy(files = (p.files + uris.map { it.toString() }).distinct())
            projects = projects.map { if (it.id == p.id) updated else it }
            saveProjects(context, projects)
            activeProject = updated
            message = "تمت إضافة ${uris.size} ملف للمشروع"
        }
    }
    MaterialTheme(colorScheme = darkColorScheme(background = Ink, surface = Panel, primary = Blue, onBackground = White, onSurface = White)) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Panel) {
                listOf("Home" to Icons.Default.Home, "Archive" to Icons.Default.Folder, "AI Studio" to Icons.Default.AutoAwesome, "Audio" to Icons.Default.GraphicEq, "Tools" to Icons.Default.Tune).forEach { (name, icon) ->
                    NavigationBarItem(selected == name, { selected = name; activeProject = null }, { Icon(icon, name) }, label = { Text(name, fontSize = 9.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Accent, selectedTextColor = Accent, indicatorColor = Color(0xFF263B59), unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp).background(Ink)) {
                Spacer(Modifier.height(20.dp))
                when (selected) {
                    "Home" -> {
                        Text("GZAR STUDIO", color = White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                        Text("YOUR CREATIVE WORKSPACE", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                        Spacer(Modifier.height(22.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { StatCard("PROJECTS", projects.size.toString(), Modifier.weight(1f)); StatCard("FILES", projects.sumOf { it.files.size }.toString(), Modifier.weight(1f)); StatCard("WORKSPACE", "READY", Modifier.weight(1f)) }
                        Spacer(Modifier.height(24.dp)); Text("WORKSPACE", color = Accent, fontWeight = FontWeight.Bold)
                        ModuleCard("Project Archive", "إنشاء مشاريعك وإضافة ملفاتك", Icons.Default.Folder) { selected = "Archive" }
                        ModuleCard("AI Design Studio", "أدوات التصميم الذكي — قيد التطوير", Icons.Default.AutoAwesome) { selected = "AI Studio" }
                        ModuleCard("Audio Lab", "مساحة أدوات الصوت — قيد التطوير", Icons.Default.GraphicEq) { selected = "Audio" }
                        ModuleCard("Creative Tools", "أدوات الفيديو والألوان — قيد التطوير", Icons.Default.Tune) { selected = "Tools" }
                    }
                    "Archive" -> {
                        if (activeProject == null) {
                            Text("PROJECT ARCHIVE", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Text("مشاريعك محفوظة على هذا الهاتف", color = Muted)
                            Spacer(Modifier.height(16.dp))
                            Button(onClick = { newName = ""; showCreate = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("إنشاء مشروع جديد") }
                            Spacer(Modifier.height(12.dp))
                            if (projects.isEmpty()) EmptyState("لسه مفيش مشاريع", "اضغط إنشاء مشروع جديد للبدء")
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(projects, key = { it.id }) { project ->
                                Card(Modifier.fillMaxWidth().clickable { activeProject = project }, colors = CardDefaults.cardColors(containerColor = Panel)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.FolderOpen, null, tint = Accent); Column(Modifier.weight(1f).padding(start = 12.dp)) { Text(project.name, color = White, fontWeight = FontWeight.SemiBold); Text("${project.files.size} ملف", color = Muted, fontSize = 11.sp) }; Icon(Icons.Default.ChevronRight, null, tint = Muted) } }
                            } }
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = { activeProject = null }) { Icon(Icons.Default.ArrowBack, null, tint = White) }; Text(activeProject!!.name, color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                            Text("${activeProject!!.files.size} ملف داخل المشروع", color = Muted)
                            Spacer(Modifier.height(16.dp))
                            Button(onClick = { picker.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Icon(Icons.Default.UploadFile, null); Spacer(Modifier.width(8.dp)); Text("إضافة ملفات من الهاتف") }
                            Spacer(Modifier.height(12.dp))
                            if (activeProject!!.files.isEmpty()) EmptyState("المشروع فارغ", "أضف صور أو فيديو أو صوت أو أي ملفات")
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(activeProject!!.files) { fileUri ->
                                    val parsed = Uri.parse(fileUri)
                                    val displayName = remember(fileUri) { getDisplayName(context, parsed) }
                                    val mime = remember(fileUri) { getMimeType(context, parsed, displayName) }
                                    val isVideo = mime?.startsWith("video/") == true || displayName.substringAfterLast('.', "").lowercase() in listOf("mp4", "mkv", "mov", "avi", "webm", "3gp", "m4v")
                                    val isImage = mime?.startsWith("image/") == true
                                    val thumbnail by produceState<Bitmap?>(initialValue = null, fileUri) {
                                        value = withContext(Dispatchers.IO) { loadThumbnail(context, parsed, isVideo, isImage) }
                                    }
                                    Card(
                                        Modifier.fillMaxWidth().clickable { openMedia(context, parsed, mime) },
                                        colors = CardDefaults.cardColors(containerColor = Panel)
                                    ) {
                                        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                            if (thumbnail != null) {
                                                Image(bitmap = thumbnail!!.asImageBitmap(), contentDescription = "غلاف $displayName", modifier = Modifier.size(76.dp, 58.dp), contentScale = ContentScale.Crop)
                                            } else {
                                                Box(Modifier.size(76.dp, 58.dp).background(Color(0xFF263B59), RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                                                    Icon(if (isVideo) Icons.Default.PlayCircle else if (mime?.startsWith("audio/") == true) Icons.Default.GraphicEq else Icons.Default.InsertDriveFile, null, tint = Accent, modifier = Modifier.size(30.dp))
                                                }
                                            }
                                            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                                Text(displayName, color = White, fontWeight = FontWeight.Medium, maxLines = 2)
                                                Text(mime ?: "نوع ملف غير معروف", color = Muted, fontSize = 11.sp)
                                                if (isVideo) Text("اضغط للتشغيل", color = Accent, fontSize = 10.sp)
                                            }
                                            if (isVideo) Icon(Icons.Default.PlayArrow, null, tint = Accent)
                                            IconButton(onClick = {
                                                val updated = activeProject!!.copy(files = activeProject!!.files.filterNot { it == fileUri })
                                                projects = projects.map { if (it.id == updated.id) updated else it }
                                                saveProjects(context, projects)
                                                activeProject = updated
                                                message = "تم حذف الملف من المشروع فقط، ولم يتم حذفه من الهاتف"
                                            }) { Icon(Icons.Default.DeleteOutline, "إزالة من المشروع", tint = Muted) }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        val title = when(selected) { "AI Studio" -> "AI DESIGN STUDIO"; "Audio" -> "AUDIO LAB"; else -> "CREATIVE TOOLS" }
                        Text(title, color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text("هذا القسم لم تكتمل وظائفه بعد. لن نعرض أدوات وهمية.", color = Muted)
                        Spacer(Modifier.height(16.dp))
                        EmptyState("قيد التطوير", "الأرشيف وإنشاء المشاريع وإضافة الملفات يعملون الآن. سيتم تفعيل أدوات هذا القسم في تحديث لاحق.")
                    }
                }
            }
        }
        if (showCreate) AlertDialog(onDismissRequest = { showCreate = false }, containerColor = Panel, title = { Text("مشروع جديد", color = White) }, text = { OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("اسم المشروع") }, singleLine = true) }, confirmButton = { TextButton(onClick = { val name = newName.trim(); if (name.isNotEmpty()) { val p = Project(System.currentTimeMillis(), name, System.currentTimeMillis()); projects = projects + p; saveProjects(context, projects); showCreate = false; activeProject = p }; }) { Text("إنشاء") } }, dismissButton = { TextButton(onClick = { showCreate = false }) { Text("إلغاء") } })
        if (message.isNotBlank()) AlertDialog(onDismissRequest = { message = "" }, confirmButton = { TextButton(onClick = { message = "" }) { Text("تمام") } }, text = { Text(message) }, containerColor = Panel)
    }
}

fun loadProjects(context: Context): List<Project> = try {
    val raw = context.getSharedPreferences("gzar_archive", Context.MODE_PRIVATE).getString("projects", "[]") ?: "[]"
    val arr = JSONArray(raw); (0 until arr.length()).map { i -> val o = arr.getJSONObject(i); val f = o.optJSONArray("files") ?: JSONArray(); Project(o.getLong("id"), o.getString("name"), o.getLong("created"), (0 until f.length()).map { f.getString(it) }) }
} catch (_: Exception) { emptyList() }
fun saveProjects(context: Context, projects: List<Project>) {
    val arr = JSONArray(); projects.forEach { p -> val files = JSONArray(); p.files.forEach { files.put(it) }; arr.put(JSONObject().put("id", p.id).put("name", p.name).put("created", p.created).put("files", files)) }
    context.getSharedPreferences("gzar_archive", Context.MODE_PRIVATE).edit().putString("projects", arr.toString()).apply()
}

@Composable fun StatCard(label: String, value: String, modifier: Modifier = Modifier) { Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) { Column(Modifier.padding(11.dp)) { Text(value, color = Accent, fontSize = 19.sp, fontWeight = FontWeight.Bold); Text(label, color = Muted, fontSize = 9.sp) } } }
@Composable fun ModuleCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) { Card(Modifier.fillMaxWidth().padding(bottom = 9.dp).clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(42.dp).background(Color(0xFF1D3B60), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Accent) }; Column(Modifier.weight(1f).padding(start = 12.dp)) { Text(title, color = White, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Muted, fontSize = 11.sp) }; Icon(Icons.Default.ChevronRight, null, tint = Muted) } } }
@Composable fun EmptyState(title: String, body: String) { Column(Modifier.fillMaxWidth().padding(vertical = 30.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.Inventory2, null, tint = Muted, modifier = Modifier.size(42.dp)); Spacer(Modifier.height(10.dp)); Text(title, color = White, fontWeight = FontWeight.Bold); Text(body, color = Muted, fontSize = 12.sp) } }


private fun getDisplayName(context: Context, uri: Uri): String {
    var name: String? = null
    try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) name = cursor.getString(0)
        }
    } catch (_: Exception) { }
    return name?.takeIf { it.isNotBlank() } ?: (uri.lastPathSegment?.substringAfterLast('/') ?: "ملف بدون اسم")
}

private fun getMimeType(context: Context, uri: Uri, name: String): String? {
    val fromProvider = try { context.contentResolver.getType(uri) } catch (_: Exception) { null }
    if (!fromProvider.isNullOrBlank() && fromProvider != "application/octet-stream") return fromProvider
    val extension = name.substringAfterLast('.', "").lowercase()
    return MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension) ?: when (extension) {
        "mkv" -> "video/x-matroska"
        "avi" -> "video/x-msvideo"
        "mov" -> "video/quicktime"
        "mp4", "m4v" -> "video/mp4"
        "3gp" -> "video/3gpp"
        else -> fromProvider
    }
}

private fun loadThumbnail(context: Context, uri: Uri, isVideo: Boolean, isImage: Boolean): Bitmap? {
    return try {
        if (isVideo) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, uri)
                retriever.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    ?: retriever.getFrameAtTime(0)
            } finally { retriever.release() }
        } else if (isImage) {
            if (Build.VERSION.SDK_INT >= 29) context.contentResolver.loadThumbnail(uri, android.util.Size(240, 180), null)
            else context.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it) }
        } else null
    } catch (_: Exception) { null }
}

private fun openMedia(context: Context, uri: Uri, mime: String?) {
    try {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime ?: "*/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "فتح الملف باستخدام"))
    } catch (_: Exception) {
        android.widget.Toast.makeText(context, "مش لاقي تطبيق يفتح نوع الملف ده", android.widget.Toast.LENGTH_LONG).show()
    }
}
